package com.example.taskmanagement

interface ItemTouchHelperAdapter {
    fun onItemDismiss(position: Int)
}
